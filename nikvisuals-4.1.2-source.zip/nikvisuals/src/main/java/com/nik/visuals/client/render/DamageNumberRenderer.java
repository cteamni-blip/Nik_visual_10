package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Environment(EnvType.CLIENT)
public class DamageNumberRenderer {
    private static final class Num {
        float x, y, vy, life, dmg;
        Num(float x, float y, float dmg) { this.x = x; this.y = y; this.dmg = dmg; vy = -0.6f; life = 1f; }
    }
    private final List<Num> nums = new ArrayList<>();
    private float lastHp = -1;
    private int lastId = -1;
    private boolean wasSwing;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.damageNumbers || mc.player == null) { nums.clear(); return; }
        boolean swinging = mc.player.handSwinging;
        if (swinging && !wasSwing && mc.crosshairTarget != null
                && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity le) {
                float hp = le.getHealth();
                if (lastId == le.getId() && lastHp > 0 && hp < lastHp) {
                    float dmg = lastHp - hp;
                    if (dmg > 0.05f) {
                        int cx = mc.getWindow().getScaledWidth() / 2;
                        int cy = mc.getWindow().getScaledHeight() / 2;
                        nums.add(new Num(cx + (float)(Math.random() * 20 - 10), cy - 20, dmg));
                    }
                }
                lastId = le.getId();
                lastHp = hp;
            }
        }
        wasSwing = swinging;
        Iterator<Num> it = nums.iterator();
        while (it.hasNext()) {
            Num n = it.next();
            n.y += n.vy;
            n.vy *= 0.96f;
            n.life -= 0.03f;
            if (n.life <= 0) it.remove();
        }
    }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.damageNumbers || nums.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Num n : nums) {
            int a = (int) (255 * Math.max(0, n.life));
            int col = (a << 24) | 0xFF6666;
            String t = String.format("%.1f", n.dmg);
            g.drawCenteredTextWithShadow(mc.textRenderer, t, (int) n.x, (int) n.y, col);
        }
    }
}
