package com.nik.visuals.client.render;

import net.minecraft.client.gui.DrawContext;

public final class GuiDraw {
    private GuiDraw() {}

    public static void fillRounded(DrawContext g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        // center + sides
        g.fill(x + r, y, x + w - r, y + h, color);
        g.fill(x, y + r, x + r, y + h - r, color);
        g.fill(x + w - r, y + r, x + w, y + h - r, color);
        // rounded corners via soft circles
        fillSoftCircle(g, x + r, y + r, r, color);
        fillSoftCircle(g, x + w - r - 1, y + r, r, color);
        fillSoftCircle(g, x + r, y + h - r - 1, r, color);
        fillSoftCircle(g, x + w - r - 1, y + h - r - 1, r, color);
    }

    public static void glassPanel(DrawContext g, int x, int y, int w, int h, int r, int fill, int border) {
        fillRounded(g, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        fillRounded(g, x, y, w, h, r, fill);
        // soft top sheen
        int sheen = (0x18 << 24) | 0xFFFFFF;
        if (h > 6) g.fill(x + r, y + 1, x + w - r, y + 2, sheen);
    }

    public static void hpBar(DrawContext g, int x, int y, int w, int h, float pct, int fill, int back) {
        pct = Math.max(0f, Math.min(1f, pct));
        int rr = Math.max(2, h / 2);
        fillRounded(g, x, y, w, h, rr, back);
        int fw = Math.max(h, (int) (w * pct));
        if (pct > 0.01f) fillRounded(g, x, y, fw, h, rr, fill);
    }

    public static void fillSoftCircle(DrawContext g, int cx, int cy, int radius, int color) {
        if (radius <= 0) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.sqrt(radius * radius - dy * dy + 0.25);
            g.fill(cx - span, cy + dy, cx + span + 1, cy + dy + 1, color);
        }
    }

    /** Pill / oval toggle — human-looking iOS style */
    public static void toggle(DrawContext g, int x, int y, int w, int h, float on, int onColor, int offColor, int knob) {
        on = Math.max(0f, Math.min(1f, on));
        int track = lerpColor(offColor, onColor, on);
        // fully pill shape
        fillRounded(g, x, y, w, h, h / 2, track);
        // subtle inner edge
        int edge = (0x22 << 24) | 0xFFFFFF;
        g.fill(x + h / 2, y + 1, x + w - h / 2, y + 2, edge);

        int pad = 2;
        int kw = h - pad * 2;
        int kx = x + pad + (int) ((w - kw - pad * 2) * on);
        int ky = y + pad;
        // shadow under knob
        fillSoftCircle(g, kx + kw / 2, ky + kw / 2 + 1, kw / 2, 0x44000000);
        fillSoftCircle(g, kx + kw / 2, ky + kw / 2, kw / 2, knob);
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (((int) (aa + (ba - aa) * t)) << 24)
             | (((int) (ar + (br - ar) * t)) << 16)
             | (((int) (ag + (bg - ag) * t)) << 8)
             |  ((int) (ab + (bb - ab) * t));
    }
}
