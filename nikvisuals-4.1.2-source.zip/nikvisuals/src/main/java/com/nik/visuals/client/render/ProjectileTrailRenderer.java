package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class ProjectileTrailRenderer {
    public void renderWorld(MatrixStack pose, VertexConsumerProvider buffers, float pt) {
        if (!ModConfig.arrowTrail) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || buffers == null) return;

        try {
            com.mojang.blaze3d.opengl.GlStateManager._disableDepthTest();
        } catch (Throwable ignored) {}

        try {
            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            pose.push();
            Matrix4f m = pose.peek().getPositionMatrix();
            VertexConsumer lines;
            try { lines = buffers.getBuffer(RenderLayers.linesTranslucent()); }
            catch (Throwable t) { lines = buffers.getBuffer(RenderLayers.lines()); }

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PersistentProjectileEntity) && !(e instanceof TridentEntity)) continue;
                if (!e.isAlive()) continue;
                Vec3d vel = e.getVelocity();
                if (vel.lengthSquared() < 0.01) continue;
                Vec3d pos = e.getLerpedPos(pt).subtract(cam);
                Vec3d back = vel.normalize().multiply(-0.8);
                float r = 0.4f, g = 0.7f, b = 1f, a = 0.7f;
                line(lines, m, pos, pos.add(back), r, g, b, a, 2f);
                line(lines, m, pos.add(back), pos.add(back.multiply(2)), r, g, b, a * 0.4f, 1.5f);
            }
            pose.pop();
        } finally {
            try {
                com.mojang.blaze3d.opengl.GlStateManager._enableDepthTest();
            } catch (Throwable ignored) {}
        }
    }

    private void line(VertexConsumer v, Matrix4f m, Vec3d a, Vec3d b, float r, float g, float bl, float al, float w) {
        float dx = (float) (b.x - a.x), dy = (float) (b.y - a.y), dz = (float) (b.z - a.z);
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        v.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
        v.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
    }
}
