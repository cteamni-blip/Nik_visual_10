package com.nik.visuals.client.mixin;

import com.nik.visuals.client.slot.SlotTimerRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderHotbar", at = @At("RETURN"), require = 0)
    private void nik$afterHotbar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        try {
            float pt = 0f;
            try {
                pt = tickCounter.getTickProgress(true);
            } catch (Throwable t1) {
                try {
                    pt = tickCounter.getGameTimeDeltaPartialTick(true);
                } catch (Throwable t2) {
                    pt = 0f;
                }
            }
            SlotTimerRenderer.renderAfterHotbar(context, pt);
        } catch (Throwable ignored) {}
    }
}
