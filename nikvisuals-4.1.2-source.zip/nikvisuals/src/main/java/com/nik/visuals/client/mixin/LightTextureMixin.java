package com.nik.visuals.client.mixin;

import com.nik.visuals.client.config.ModConfig;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LightmapTextureManager.class)
public class LightTextureMixin {
    /** Bumps sky/block light factor used while building the lightmap */
    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 0, require = 0)
    private float nik$gammaBoost(float value) {
        if (ModConfig.fullbright) {
            return Math.max(value, 1.0f);
        }
        return value;
    }

    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 1, require = 0)
    private float nik$skyBoost(float value) {
        if (ModConfig.fullbright) {
            return Math.max(value, 1.0f);
        }
        return value;
    }

    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 2, require = 0)
    private float nik$blockBoost(float value) {
        if (ModConfig.fullbright) {
            return Math.max(value, 1.0f);
        }
        return value;
    }
}
