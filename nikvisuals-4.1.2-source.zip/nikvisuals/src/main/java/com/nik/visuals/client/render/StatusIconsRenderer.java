package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

@Environment(EnvType.CLIENT)
public class StatusIconsRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.statusIcons) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;

        int x = mc.getWindow().getScaledWidth() / 2 - 10;
        int y = mc.getWindow().getScaledHeight() / 2 + 18;
        // sprint
        if (p.isSprinting()) {
            g.drawCenteredTextWithShadow(mc.textRenderer, "§a▶", x - 14, y, Style.TEXT);
        }
        // low hunger
        if (p.getHungerManager().getFoodLevel() <= 6) {
            g.drawCenteredTextWithShadow(mc.textRenderer, "§c🍖", x + 14, y, Style.TEXT);
        }
        // can crit-ish: on ground not sprinting
        if (p.isOnGround() && !p.isSprinting() && p.getAttackCooldownProgress(0) > 0.9f) {
            g.drawCenteredTextWithShadow(mc.textRenderer, "§e✦", x, y, Style.TEXT);
        }
    }
}
