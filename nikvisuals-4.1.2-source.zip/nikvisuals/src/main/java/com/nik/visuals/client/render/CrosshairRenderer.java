package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class CrosshairRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.customCrosshair) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int col = ModConfig.crosshairColor | 0xFF000000;
        int out = 0xFF000000;
        int size = Math.max(2, Math.min(12, ModConfig.crosshairSize));
        int gap = Math.max(0, Math.min(8, ModConfig.crosshairGap));
        int th = Math.max(1, Math.min(3, ModConfig.crosshairThickness));
        int style = ModConfig.crosshairStyle; // 0 cross, 1 cross+dot, 2 dot, 3 circle, 4 T

        if (style == 2) {
            // dot only
            fillBox(g, cx - th, cy - th, th * 2 + 1, th * 2 + 1, out);
            fillBox(g, cx - th + 1, cy - th + 1, Math.max(1, th * 2 - 1), Math.max(1, th * 2 - 1), col);
            return;
        }
        if (style == 3) {
            // circle approx
            int r = size + gap;
            for (int i = 0; i < 16; i++) {
                double a0 = Math.PI * 2 * i / 16;
                double a1 = Math.PI * 2 * (i + 1) / 16;
                int x0 = cx + (int) Math.round(Math.cos(a0) * r);
                int y0 = cy + (int) Math.round(Math.sin(a0) * r);
                int x1 = cx + (int) Math.round(Math.cos(a1) * r);
                int y1 = cy + (int) Math.round(Math.sin(a1) * r);
                g.fill(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1) + 1, Math.max(y0, y1) + 1, col);
            }
            if (style == 3 && ModConfig.crosshairDot) {
                fillBox(g, cx - 1, cy - 1, 3, 3, col);
            }
            return;
        }

        // cross arms
        // left
        fillBox(g, cx - gap - size, cy - th / 2, size, th, out);
        fillBox(g, cx - gap - size + 1, cy - th / 2 + (th > 1 ? 1 : 0), Math.max(1, size - 2), Math.max(1, th - (th > 1 ? 2 : 0)), col);
        // right
        fillBox(g, cx + gap + 1, cy - th / 2, size, th, out);
        fillBox(g, cx + gap + 2, cy - th / 2 + (th > 1 ? 1 : 0), Math.max(1, size - 2), Math.max(1, th - (th > 1 ? 2 : 0)), col);
        // up (skip for T-style)
        if (style != 4) {
        fillBox(g, cx - th / 2, cy - gap - size, th, size, out);
        fillBox(g, cx - th / 2 + (th > 1 ? 1 : 0), cy - gap - size + 1, Math.max(1, th - (th > 1 ? 2 : 0)), Math.max(1, size - 2), col);
        }
        // down
        fillBox(g, cx - th / 2, cy + gap + 1, th, size, out);
        fillBox(g, cx - th / 2 + (th > 1 ? 1 : 0), cy + gap + 2, Math.max(1, th - (th > 1 ? 2 : 0)), Math.max(1, size - 2), col);

        if (style == 1 || ModConfig.crosshairDot) {
            fillBox(g, cx - 1, cy - 1, 3, 3, out);
            fillBox(g, cx, cy, 1, 1, col);
        }
    }

    private static void fillBox(DrawContext g, int x, int y, int w, int h, int c) {
        if (w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, c);
    }
}
