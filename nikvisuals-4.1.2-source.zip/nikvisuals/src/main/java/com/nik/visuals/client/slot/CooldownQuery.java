package com.nik.visuals.client.slot;

import com.nik.visuals.client.mixin.CooldownInstanceAccessor;
import com.nik.visuals.client.mixin.ItemCooldownsAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

@Environment(EnvType.CLIENT)
public final class CooldownQuery {
    private CooldownQuery() {}

    /**
     * Remaining whole seconds for this stack's cooldown, or -1 if none / under 1s.
     */
    public static int remainingSeconds(ClientPlayerEntity player, ItemStack stack, float partial) {
        if (player == null || stack == null || stack.isEmpty()) return -1;
        try {
            ItemCooldownManager mgr = player.getItemCooldownManager();
            float progress = mgr.getCooldownProgress(stack, partial);
            if (progress <= 0.001f) return -1;

            int tick = -1;
            int end = -1;
            int start = -1;

            // 1) accessor path
            if (mgr instanceof ItemCooldownsAccessor acc) {
                tick = acc.getTick();
                Object entry = findEntry(acc.getCooldowns(), stack, mgr, progress, partial);
                if (entry instanceof CooldownInstanceAccessor ce) {
                    end = ce.getEndTick();
                    try { start = ce.getStartTick(); } catch (Throwable ignored) {}
                } else if (entry != null) {
                    end = readInt(entry, "endTick", "end", "field_19267");
                    start = readInt(entry, "startTick", "start", "field_19266");
                }
            }

            // 2) reflection on manager fields if still missing
            if (end < 0) {
                Object entry = reflectFindEntry(mgr, stack);
                if (entry != null) {
                    end = readInt(entry, "endTick", "end", "field_19267");
                    start = readInt(entry, "startTick", "start", "field_19266");
                    tick = readInt(mgr, "tick", "field_19264");
                }
            }

            if (end >= 0 && tick >= 0 && end > tick) {
                int remTicks = Math.max(0, (int) Math.ceil(end - tick - partial));
                int sec = (int) Math.ceil(remTicks / 20.0);
                return sec < 1 ? -1 : sec;
            }
            if (start >= 0 && end > start) {
                int sec = (int) Math.ceil(progress * (end - start) / 20.0);
                return sec < 1 ? -1 : sec;
            }

            // 3) last resort: progress alone is fraction remaining — assume common 1s/2s/5s by progress slope not available
            // Show only if progress suggests at least ~1s of a 1s CD (progress>=1) — weak
            return -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    private static Object findEntry(Map<?, ?> map, ItemStack stack, ItemCooldownManager mgr, float progress, float partial) {
        if (map == null || map.isEmpty()) return null;
        Object byItem = map.get(stack.getItem());
        if (byItem != null) return byItem;
        // cooldown group component
        try {
            var group = stack.get(net.minecraft.component.DataComponentTypes.USE_COOLDOWN);
            if (group != null) {
                Object id = null;
                try {
                    Method m = group.getClass().getMethod("cooldownGroup");
                    id = m.invoke(group);
                } catch (Throwable ignored) {}
                if (id != null && map.get(id) != null) return map.get(id);
            }
        } catch (Throwable ignored) {}
        // scan: pick entry whose remaining matches progress roughly
        for (Object v : map.values()) {
            if (v == null) continue;
            int end = readInt(v, "endTick", "end");
            int start = readInt(v, "startTick", "start");
            int tick = -1;
            if (mgr instanceof ItemCooldownsAccessor a) tick = a.getTick();
            if (end > tick && start >= 0 && end > start) {
                float p = (end - tick - partial) / (float) (end - start);
                if (Math.abs(p - progress) < 0.08f) return v;
            }
        }
        if (map.size() == 1) return map.values().iterator().next();
        return null;
    }

    private static Object reflectFindEntry(ItemCooldownManager mgr, ItemStack stack) {
        try {
            for (Field f : mgr.getClass().getDeclaredFields()) {
                if (!Map.class.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                Object m = f.get(mgr);
                if (m instanceof Map<?, ?> map) {
                    Object v = map.get(stack.getItem());
                    if (v != null) return v;
                    if (map.size() == 1) return map.values().iterator().next();
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static int readInt(Object o, String... names) {
        Class<?> c = o.getClass();
        while (c != null && c != Object.class) {
            for (String n : names) {
                try {
                    Field f = c.getDeclaredField(n);
                    f.setAccessible(true);
                    return f.getInt(o);
                } catch (Throwable ignored) {}
            }
            c = c.getSuperclass();
        }
        return -1;
    }
}
